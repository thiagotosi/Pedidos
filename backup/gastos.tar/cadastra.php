<?php

$descricao = $_POST['campo_descricao'];
$valor = $_POST['campo_valor'];
$tipo = $_POST['opcao_tipo'];
$cartao = $_POST['campo_cartao'];


// Create connection
$conn = new mysqli("mysql.thiagotosi.com", "thiagotosi06", "5744757447", "thiagotosi06");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO thiagotosi06.dinheiro (descricao, valor, data)
VALUES ('$descricao', $valor, NOW())";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
