<?php

$conn = new mysqli("mysql.thiagotosi.com", "thiagotosi06", "5744757447", "thiagotosi06");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$soma = 0;
$dados = array();
$sql = "SELECT * FROM dinheiro";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $soma = $soma + $row["valor"];
        echo "id: " . $row["id"]. " - Descricao: " . $row["descricao"]. " " . $row["valor"]. "<br>";
    }
} else {
    echo "0 results";
}

echo "<br><br>Total: R$ " . $soma ;
$conn->close();
