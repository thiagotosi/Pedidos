<!DOCTYPE html>
<html lang="pt-br">
   <head>
       <meta charset="utf-8"/>
       <title>Cadastro de Gastos</title>
       <link href="css/bootstrap.min.css" rel="stylesheet">
       <style>
	.btn{ width:200px;height:80px;font-size:40px; }
	.valorCampo{ height:150px; width:150px; }
       </style>
   </head>
   <body style="padding:50px;  font-size:70px;">


<?php
	if($_POST['campo_descricao']){
		require_once("cadastra.php");
	}
?>
<form action="" method="post">
   		<table>
   			<tr height="100">
   				<td width="400">Forma de Pagamento: </td>
   				<td>
   					<label>
    					<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
   						Dinheiro
  					</label><br>
  					<label>
  						<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
   						Débito
  					</label><br>
  					<label>
  						<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
   						Crédito
  					</label>
  				</td>
   			</tr>
   			<tr height="100">
   				<td><label for="valorCampo">Valor: </label></td>
   				<td><input style="height:50px; width:200px;" type="text" class="form-control" name="campo_valor" id="valorCampo" class="valorCampo"  placeholder="Digite o valor"></td>
   			</tr>
			 <tr height="100">
                                <td><label for="campo_descricao">Descricao: </label></td>
                                <td><input style="height:50px; width:200px;" type="text" class="form-control" name="campo_descricao" id="campo_descricao" class="campo_descricao"  placeholder="Descricao"></td>
                        </tr>
   			<tr height="100">
				<td>
				</td>
   				<td><button type="submit" class="btn btn-primary btn-lg">Cadastrar</button></td>
   			</tr>

   		</table>

	</form>
       <p>
			
		</p>
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
   </body>
</html>
